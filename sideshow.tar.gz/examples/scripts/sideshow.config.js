Sideshow.config.language = "uk";
Sideshow.config.tranlations.availableWizards['uk'] = "Доступні Туторіали";
Sideshow.config.tranlations.relatedWizards['uk'] = "Інші уроки";
Sideshow.config.tranlations.noAvailableWizards['uk'] = "Не знайдено доступних уроків";
Sideshow.config.tranlations.close['uk'] = "Закрити";
Sideshow.config.tranlations.estimatedTime['uk'] = "Час уроку";
Sideshow.config.tranlations.next['uk'] = "Далі";
Sideshow.config.tranlations.finishWizard['uk'] = "Завершити урок";
Sideshow.init();
