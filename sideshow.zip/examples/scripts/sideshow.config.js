Sideshow.config.language = "uk";
Sideshow.config.tranlations = {
  availableWizards: {
    "en": "Доступні Туторіали"
  },
  relatedWizards: {
    "en": "Інші уроки"
  },
  noAvailableWizards: {
    "en": "Не знайдено доступних уроків"
  },
  close: {
    "en": "Закрити"
  },
  estimatedTime: {
    "en": "Час уроку"
  },
  next: {
    "en": "Далі"
  },
  finishWizard: {
    "en": "Завершити урок"
  }
};
Sideshow.init();
